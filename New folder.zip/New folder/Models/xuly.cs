﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace web.Models
{
    public class xuly
    {
        public string conf = "Data Source=KID;Initial Catalog=QL_NhaSach;User ID=sa";
    }
}